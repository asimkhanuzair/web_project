const express = require("express");
const mongoose = require("mongoose");
const multer = require("multer");
const fs = require("fs");

const app = express();
const { AdminUser, Courses, customer } = require("./model");
var cors = require("cors");

// creating connection with database
app.use(
  express.urlencoded({
    extended: true,
  })
);
app.use(express.json());
app.use(cors());
const port = process.env.PORT || 5000;
mongoose
  .connect("mongodb://127.0.0.1:27017/react1DB", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    // useCreateIndex: true,
  })
  .then(() => {
    console.log("Connection Suecessfully Created!");
  })
  .catch((err) => {
    console.log("No Connection Created! ");
  });

// creating connection with database end
app.post("/CheckAdmin", (req, res) => {
  const { username, password } = req.body;
  AdminUser.find({ username: username, password: password })
    .then((result) => {
      if (result.length >= 1) {
        res.status(200).send({ result: "user found" });
      } else {
        res.status(400).send({ result: "user not found" });
      }
    })
    .catch((err) => {
      res.status(400).send({ result: err.message });
    });
});
// Front Customer
app.post("/CheckUser", (req, res) => {
  const { username, password } = req.body;
  customer
    .find({ username: username, password: password })
    .then((result) => {
      if (result.length >= 1) {
        res.status(200).send({ result: "user found" });
      } else {
        res.status(400).send({ result: "user not found" });
      }
    })
    .catch((err) => {
      res.status(400).send({ result: err.message });
    });
});

// Add Course
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./uploads");
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  },
});
const upload = multer({ storage });
const type = upload.single("file");
// Get Course
app.get("/getcourse", (req, res) => {
  Courses.find({}).then((result) => {
    res.status(200).send(result);
  });
});
// get dingle course
app.post("/get_single_course", (req, res) => {
  const { id } = req.body;
  Courses.find({ _id: id }).then((result) => {
    res.status(200).send(result);
  });
});
// Add Course
app.post("/addcourse", type, (req, res) => {
  const { title, author, rating, description, ImgName } = req.body;
  if (title !== undefined && ImgName !== undefined) {
    const CourseAdd = new Courses({
      title,
      author,
      rating,
      description,
      image: ImgName,
      imgcontent: {
        data: fs.readFileSync(`uploads/${req.file.filename}`),
        contentType: "image/png",
      },
    });
    CourseAdd.save()
      .then(() => {
        res.status(200).json({ status: "OK" });
      })
      .catch((error) => {
        res.status(400).json({ status: error.message });
      });
    return;
  }
  res.status(400).send({ status: "Not OK" });
});
// Delete Course
app.post("/delete_course", (req, res) => {
  const { id } = req.body;
  Courses.deleteOne({ _id: id })
    .then((response) => {
      res.status(200).send(response);
    })
    .catch((err) => res.status(400).send(err));
});
//update Course
app.post("/update_course", type, (req, res) => {
  const { title, author, rating, description, ImgName } = req.body;
  const _id = req.body._id;
  const update = {
    title,
    author,
    rating,
    description,
    image: ImgName,
    imgcontent: {
      data: fs.readFileSync(`uploads/${req.file.filename}`),
      contentType: "image/png",
    },
  };
  Courses.findByIdAndUpdate(mongoose.Types.ObjectId(_id), update)
    .then(() => {
      res.status(200).send({ status: "Successfully Update" });
    })
    .catch((error) => {
      res.status(400).send({ status: error.message });
    });
});
// Update Product
app.post("/not_img_update_course", (req, res) => {
  const _id = req.body._id;
  const update = {
    title: req.body.title,
    author: req.body.author,
    rating: req.body.rating,
    description: req.body.description,
  };
  Courses.findByIdAndUpdate(mongoose.Types.ObjectId(_id), update)
    .then(() => {
      res.status(200).send({ status: "Successfully Update" });
    })
    .catch((error) => {
      res.status(400).send({ status: error.message });
    });
});
// Video Upload
app.post("/VideoAdd", type, (req, res) => {
  const { _id, title, ImgName } = req.body;
  if (title !== undefined && ImgName !== undefined) {
    const update = {
      video: [
        {
          title: title,
          videotitle: ImgName,
        },
      ],
    };

    Courses.findByIdAndUpdate(mongoose.Types.ObjectId(_id), update)
      .then(() => {
        res.status(200).send({ status: "Successfully Update" });
      })
      .catch((error) => {
        res.status(400).send({ status: error.message });
      });
    return;
  }
  res.status(400).send({ status: "Not OK" });
});
// Get
app.get("/getVideo", (req, res) => {
  Courses.find({}).then((result) => {
    res.status(200).send(result);
  });
});
app.get("/", (req, res) => {
  res.send("This is home page.");
});

app.post("/", (req, res) => {
  res.send("This is home page with post request.");
});

app.listen(port, () => {
  console.log(`Server is running on PORT: ${port}`);
});
