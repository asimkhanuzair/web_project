const mongoose = require("mongoose");
// const { Int32, Double, Decimal128 } = require("mongodb");
const adminuser = new mongoose.Schema({
  username: String,
  password: String,
});
//
const Customer = new mongoose.Schema({
  username: String,
  password: String,
});
const course = new mongoose.Schema({
  id: Number,
  title: String,
  author: String,
  rating: String,
  description: String,
  image: String,
  imgcontent: {
    data: Buffer,
    contentType: String,
  },
  video: [{ title: String, videotitle: String }],
});

// create collection
const AdminUser = mongoose.model("AdminUsers", adminuser);
const Courses = mongoose.model("Courses", course);
const customer = mongoose.model("Customers", Customer);

module.exports = {
  AdminUser,
  Courses,
  customer,
};
